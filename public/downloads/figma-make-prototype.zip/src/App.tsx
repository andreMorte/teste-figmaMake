import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Calculator, 
  ArrowRight, 
  CheckCircle2, 
  User, 
  FileText, 
  ChevronLeft,
  Sparkles,
  Lock,
  Percent,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { uxlab } from './uxlab-sdk';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'simulacao' | 'dados-proponente' | 'revisao-proposta' | 'proposta-enviada'>('simulacao');

  const [loanAmount, setLoanAmount] = useState<number>(150000);
  const [termMonths, setTermMonths] = useState<number>(120);
  const [propertyValue, setPropertyValue] = useState<number>(450000);

  const [fullName, setFullName] = useState<string>('Carlos Eduardo Mendes');
  const [cpf, setCpf] = useState<string>('123.456.789-00');
  const [email, setEmail] = useState<string>('carlos.mendes@email.com');
  const [phone, setPhone] = useState<string>('(11) 98765-4321');
  const [income, setIncome] = useState<number>(12500);

  const [formErrors, setFormErrors] = useState<string[]>([]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.UXLab = window.UXLab || { init: () => {} };
      window.UXLab.init({
        testId: 'TEST-001',
        trackingId: 'UX-001'
      });
      uxlab.init({
        testId: 'TEST-001',
        trackingId: 'UX-001'
      });
      console.log('[UXLab] Telemetria e mapa de calor ativos para o teste TEST-001');
    }
  }, []);

  useEffect(() => {
    uxlab.setScreen(currentScreen);
  }, [currentScreen]);

  const monthlyRate = 0.0109;
  const estimatedMonthlyPayment = Math.round(
    (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths))) /
    (Math.pow(1 + monthlyRate, termMonths) - 1)
  );

  const handleAdvanceToApplicant = () => {
    uxlab.completeTask('TASK-1', {
      loanAmount,
      termMonths,
      estimatedMonthlyPayment
    });
    setCurrentScreen('dados-proponente');
  };

  const handleAdvanceToReview = () => {
    const errors: string[] = [];
    if (!fullName.trim()) errors.push('Nome completo obrigatório');
    if (!cpf.trim()) errors.push('CPF obrigatório');
    if (income <= 0) errors.push('Informe a renda mensal');

    if (errors.length > 0) {
      setFormErrors(errors);
      uxlab.reportError('TASK-2', 'Validação de dados falhou');
      return;
    }

    setFormErrors([]);
    uxlab.completeTask('TASK-2', {
      fullName,
      cpf,
      income,
      propertyValue
    });
    setCurrentScreen('revisao-proposta');
  };

  const handleConfirmProposal = () => {
    uxlab.completeTask('TASK-3', {
      confirmed: true,
      protocol: 'PR-98214-SP'
    });
    setCurrentScreen('proposta-enviada');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center justify-start p-4 sm:p-6 font-sans">
      <header className="w-full max-w-xl bg-white border border-slate-200/80 rounded-2xl shadow-xs px-5 py-3 mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-900 tracking-tight">Porto • Crédito com Garantia</h1>
            <p className="text-[11px] text-slate-500 font-mono">Figma Make Prototype • TEST-001</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 text-[11px] font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            UXLab Ativo
          </span>
        </div>
      </header>

      <main className="w-full max-w-xl bg-white border border-slate-200/90 rounded-3xl shadow-sm overflow-hidden flex flex-col">
        <div className="px-6 pt-5 pb-3 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-blue-600 text-white">
              {currentScreen === 'simulacao' ? '1' : '✓'}
            </span>
            <span className="font-semibold text-slate-700">Simulação</span>
          </div>
          <div className="h-0.5 w-6 bg-slate-200" />
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 text-slate-700">
              {currentScreen === 'revisao-proposta' || currentScreen === 'proposta-enviada' ? '✓' : '2'}
            </span>
            <span className="font-semibold text-slate-700">Proponente</span>
          </div>
          <div className="h-0.5 w-6 bg-slate-200" />
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 text-slate-700">
              {currentScreen === 'proposta-enviada' ? '✓' : '3'}
            </span>
            <span className="font-semibold text-slate-700">Revisão</span>
          </div>
        </div>

        {currentScreen === 'simulacao' && (
          <div className="p-6 space-y-6">
            <div>
              <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md mb-2">
                <Calculator className="w-3.5 h-3.5" />
                Tarefa 1: Simular Empréstimo
              </div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">Quanto você precisa emprestado?</h2>
              <p className="text-xs text-slate-500 mt-1">Taxas a partir de 1,09% a.m. com garantia do seu imóvel.</p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-600">Valor do Crédito</span>
                <span className="text-lg font-bold text-blue-600">
                  R$ {loanAmount.toLocaleString('pt-BR')}
                </span>
              </div>
              <input
                type="range"
                min="50000"
                max="1000000"
                step="10000"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
                data-tracking="slider-valor-credito"
              />
              <div className="flex justify-between text-[11px] text-slate-600 font-medium">
                <span>R$ 50.000</span>
                <span>R$ 1.000.000</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-700">Prazo de Pagamento</label>
              <div className="grid grid-cols-4 gap-2">
                {[60, 120, 180, 240].map((months) => (
                  <button
                    key={months}
                    type="button"
                    onClick={() => setTermMonths(months)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all ${
                      termMonths === months
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                    data-tracking={`btn-prazo-${months}m`}
                  >
                    {months} meses
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-50/70 to-indigo-50/70 border border-blue-100 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-500 font-medium block">Parcela Estimada</span>
                <span className="text-2xl font-bold text-slate-900 tracking-tight">
                  R$ {estimatedMonthlyPayment.toLocaleString('pt-BR')}
                  <span className="text-xs font-normal text-slate-500"> /mês</span>
                </span>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-slate-500 font-medium block">Taxa Estimada</span>
                <span className="text-sm font-bold text-emerald-600">1,09% a.m.</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAdvanceToApplicant}
              className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
              data-tracking="btn-continuar-simulacao"
            >
              <span>Continuar Simulação</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {currentScreen === 'dados-proponente' && (
          <div className="p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md mb-1">
                  <User className="w-3.5 h-3.5" />
                  Tarefa 2: Preencher Dados do Proponente
                </div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">Seus Dados Cadastrais</h2>
              </div>
              <button
                type="button"
                onClick={() => setCurrentScreen('simulacao')}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1"
                data-tracking="btn-voltar-simulacao"
              >
                <ChevronLeft className="w-4 h-4" />
                Voltar
              </button>
            </div>

            {formErrors.length > 0 && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formErrors.join(', ')}</span>
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nome Completo</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-white"
                  data-tracking="input-nome-completo"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">CPF</label>
                  <input
                    type="text"
                    value={cpf}
                    onChange={(e) => setCpf(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-white"
                    data-tracking="input-cpf"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Celular</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-white"
                    data-tracking="input-celular"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">E-mail Profissional</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-white"
                  data-tracking="input-email"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Renda Mensal Comprovada (R$)</label>
                  <input
                    type="number"
                    value={income}
                    onChange={(e) => setIncome(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-white"
                    data-tracking="input-renda-mensal"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Valor Estimado do Imóvel (R$)</label>
                  <input
                    type="number"
                    value={propertyValue}
                    onChange={(e) => setPropertyValue(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-white"
                    data-tracking="input-valor-imovel"
                  />
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAdvanceToReview}
              className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all mt-4"
              data-tracking="btn-avancar-revisao"
            >
              <span>Avançar para Revisão</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {currentScreen === 'revisao-proposta' && (
          <div className="p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md mb-1">
                  <FileText className="w-3.5 h-3.5" />
                  Tarefa 3: Revisar e Confirmar Envio
                </div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">Resumo da sua Proposta</h2>
              </div>
              <button
                type="button"
                onClick={() => setCurrentScreen('dados-proponente')}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1"
                data-tracking="btn-voltar-dados"
              >
                <ChevronLeft className="w-4 h-4" />
                Voltar
              </button>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Valor do Empréstimo:</span>
                <span className="font-bold text-slate-900">R$ {loanAmount.toLocaleString('pt-BR')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Prazo Solicitado:</span>
                <span className="font-bold text-slate-900">{termMonths} meses</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Parcela Estimada:</span>
                <span className="font-bold text-blue-600">R$ {estimatedMonthlyPayment.toLocaleString('pt-BR')}/mês</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Proponente:</span>
                <span className="font-medium text-slate-800">{fullName} ({cpf})</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Garantia Imobiliária:</span>
                <span className="font-medium text-slate-800">Avaliada em R$ {propertyValue.toLocaleString('pt-BR')}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleConfirmProposal}
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
              data-tracking="btn-confirmar-proposta"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirmar Envio da Proposta</span>
            </button>
          </div>
        )}

        {currentScreen === 'proposta-enviada' && (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-100 border-4 border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full mb-2">
                Jornada Concluída
              </span>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Proposta Enviada para Análise!</h2>
              <p className="text-xs text-slate-500 mt-2 max-w-sm mx-auto">
                Todas as tarefas foram concluídas e registradas com sucesso pelo UXLab SDK.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setCurrentScreen('simulacao')}
              className="py-2.5 px-5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all"
            >
              Reiniciar Simulação
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
