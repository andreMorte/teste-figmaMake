# Protótipo Figma Make (Jornada de Empréstimo com Garantia)
**Instrumentado para UX Test Lab (ID: `TEST-001` | Tracking: `UX-001`)**

Este pacote contém o projeto completo em **React 19 + TypeScript + Vite + Tailwind CSS**, já configurado com a instrumentação de telemetria em tempo real do **UXLab SDK**.

## 🚀 Como importar no Figma Make
1. Abra o seu projeto no Figma Make.
2. Copie os arquivos da pasta `src/` e a raiz para o projeto no Figma Make.
3. Publique a URL do seu protótipo (`*.figma.site`).
4. Utilize a URL no **UX Test Lab** para validação e testes!

## 💻 Como executar localmente
```bash
npm install
npm run dev
```
