/**
 * UXLab Telemetry & Interaction Capture SDK for Figma Make
 * Test ID: TEST-U92DU | Tracking ID: UX-QK8UY
 */

export interface UXLabEvent {
  eventType: 'CLICK' | 'SCREEN_VIEW' | 'TASK_SUCCESS' | 'TASK_ERROR' | 'BACK' | 'PAGE_VIEW';
  screen: string;
  element?: string;
  x?: number;
  y?: number;
  normalizedX?: number;
  normalizedY?: number;
  taskId?: string;
  metadata?: Record<string, any>;
}

class UXLabClient {
  private testId: string = 'TEST-U92DU';
  private trackingId: string = 'UX-QK8UY';
  private currentScreen: string = 'simulacao';
  private initialized: boolean = false;

  public init(config: { testId: string; trackingId: string }) {
    this.testId = config.testId;
    this.trackingId = config.trackingId;
    this.initialized = true;

    // Disparar confirmação de handshake
    this.sendToParent({
      type: 'UXLAB_SDK_CONNECTED',
      testId: this.testId,
      trackingId: this.trackingId,
      timestamp: new Date().toISOString(),
      status: 'connected'
    });

    // Anexar listener global de cliques para telemetria e mapa de calor
    if (typeof window !== 'undefined') {
      window.addEventListener('click', (e) => this.handleGlobalClick(e), true);
    }
  }

  public setScreen(screenName: string) {
    this.currentScreen = screenName;
    this.sendToParent({
      type: 'SCREEN_VIEW',
      screen: screenName,
      screenId: screenName,
      screenName: screenName,
      testId: this.testId,
      timestamp: new Date().toISOString()
    });
  }

  public completeTask(taskId: string, metadata?: Record<string, any>) {
    this.sendToParent({
      type: 'TASK_COMPLETED',
      taskId,
      testId: this.testId,
      screen: this.currentScreen,
      timestamp: new Date().toISOString(),
      metadata
    });
  }

  public reportError(taskId?: string, message?: string) {
    this.sendToParent({
      type: 'TASK_ERROR',
      taskId,
      screen: this.currentScreen,
      message,
      timestamp: new Date().toISOString()
    });
  }

  private handleGlobalClick(e: MouseEvent) {
    const target = e.target as HTMLElement | null;
    const elementTag = target ? (target.getAttribute('data-tracking') || target.id || target.tagName.toLowerCase()) : 'unknown';

    const x = Math.round(e.clientX);
    const y = Math.round(e.clientY);
    const normalizedX = window.innerWidth > 0 ? Math.round((x / window.innerWidth) * 1000) / 1000 : 0.5;
    const normalizedY = window.innerHeight > 0 ? Math.round((y / window.innerHeight) * 1000) / 1000 : 0.5;

    this.sendToParent({
      type: 'TRACK_EVENT',
      eventType: 'CLICK',
      screen: this.currentScreen,
      element: elementTag,
      x,
      y,
      normalizedX,
      normalizedY,
      testId: this.testId,
      trackingId: this.trackingId,
      timestamp: new Date().toISOString()
    });
  }

  private sendToParent(data: any) {
    try {
      if (typeof window !== 'undefined') {
        if (window.parent && window.parent !== window) {
          window.parent.postMessage(data, '*');
        }
      }
    } catch (err) {
      console.warn('[UXLab SDK] postMessage error:', err);
    }
  }
}

export const uxlab = new UXLabClient();
